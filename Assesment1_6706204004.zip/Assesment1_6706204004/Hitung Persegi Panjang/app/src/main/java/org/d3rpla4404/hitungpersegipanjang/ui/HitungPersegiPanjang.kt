package org.d3rpla4404.hitungpersegipanjang.ui

import android.os.Bundle
import android.text.TextUtils
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import org.d3if4077.hitungpersegipanjang.R
import org.d3if4077.hitungpersegipanjang.databinding.FragmentInputLuasKelilingBinding

class HitungPersegiPanjang : Fragment() {

    private lateinit var binding: FragmentInputLuasKelilingBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInputLuasKelilingBinding.inflate(
            layoutInflater, container, false
        )

        binding.hitung.setOnClickListener { goHasil() }
        binding.reset.setOnClickListener { reset() }
        return binding.root
    }

    private fun goHasil() {
        val cek = cekInput()
        if (cek) {
            val panjangText = binding.panjangEditText.text.toString().toFloat()
            val lebarText = binding.lebarEditText.text.toString().toFloat()
            val userCari = hitungUser()
            val action =
                HitungPersegiPanjangDirections.actionHitungPersegiPanjangToHasilHitungSisi(
                    panjangText,
                    lebarText,
                    userCari
                )
            view?.findNavController()?.navigate(action)
        }
    }

    private fun cekInput(): Boolean {
        val panjangText = binding.panjangEditText.text.toString()
        val lebarText = binding.lebarEditText.text.toString()
        val selectedId = binding.radioGroup.checkedRadioButtonId
        return when {
            TextUtils.isEmpty(panjangText) -> {
                Toast.makeText(context, R.string.panjang_invalid, Toast.LENGTH_LONG).show()
                false
            }
            TextUtils.isEmpty(lebarText) -> {
                Toast.makeText(context, R.string.lebar_invalid, Toast.LENGTH_LONG).show()
                false
            }
            selectedId == -1 -> {
                Toast.makeText(context, R.string.hitung_invalid, Toast.LENGTH_LONG).show()
                false
            }
            else -> true
        }
    }

    private fun hitungUser(): String {
        return when (binding.radioGroup.checkedRadioButtonId) {
            R.id.luasRadioButton -> {
                "luas"
            }
            R.id.kelilingRadioButton -> {
                "keliling"
            }
            else -> {
                "keduanya"
            }
        }
    }

    private fun reset() {
        binding.panjangEditText.text.clear()
        binding.lebarEditText.text.clear()
        binding.radioGroup.clearCheck()
    }
}