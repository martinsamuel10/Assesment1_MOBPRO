package org.d3rpla4404.hitungpersegipanjang.ui

import androidx.fragment.app.Fragment
import org.d3rpla4404.hitungpersegipanjang.R

class AboutFragment: Fragment(R.layout.fragment_about) {
}